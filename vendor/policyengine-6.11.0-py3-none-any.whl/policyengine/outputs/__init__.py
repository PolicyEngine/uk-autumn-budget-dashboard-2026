from policyengine.core import Output, OutputCollection
from policyengine.outputs.aggregate import Aggregate, AggregateType
from policyengine.outputs.change_aggregate import (
    ChangeAggregate,
    ChangeAggregateType,
)
from policyengine.outputs.cliff_impact import (
    CliffImpact,
    CliffImpactInSimulation,
    calculate_cliff_impact,
    configure_cliff_impact_variables,
)
from policyengine.outputs.congressional_district_impact import (
    CongressionalDistrictImpact,
    compute_us_congressional_district_impacts,
)
from policyengine.outputs.constituency_impact import (
    ConstituencyImpact,
    compute_uk_constituency_impacts,
)
from policyengine.outputs.decile_impact import (
    DecileImpact,
    calculate_decile_impacts,
)
from policyengine.outputs.inequality import (
    UK_INEQUALITY_INCOME_VARIABLE,
    US_INEQUALITY_INCOME_VARIABLE,
    Inequality,
    USInequalityPreset,
    calculate_uk_inequality,
    calculate_us_inequality,
)
from policyengine.outputs.intra_decile_impact import (
    IntraDecileImpact,
    compute_intra_decile_impacts,
)
from policyengine.outputs.labor_supply_response import (
    HoursResponse,
    LaborSupplyResponse,
    calculate_labor_supply_response,
    configure_labor_supply_response_variables,
    labor_supply_response_is_active,
)
from policyengine.outputs.local_authority_impact import (
    LocalAuthorityImpact,
    compute_uk_local_authority_impacts,
)
from policyengine.outputs.poverty import (
    AGE_GROUPS,
    GENDER_GROUPS,
    RACE_GROUPS,
    UK_POVERTY_VARIABLES,
    US_POVERTY_VARIABLES,
    Poverty,
    UKPovertyType,
    USPovertyType,
    calculate_uk_poverty_by_age,
    calculate_uk_poverty_by_gender,
    calculate_uk_poverty_rates,
    calculate_us_poverty_by_age,
    calculate_us_poverty_by_gender,
    calculate_us_poverty_by_race,
    calculate_us_poverty_rates,
)
from policyengine.outputs.program_statistics import (
    ProgramStatistics,
    build_program_statistics,
    validate_program_statistics_config,
)
from policyengine.outputs.uk_geography_assets import (
    CONSTITUENCY_ASSET_SPEC,
    LOCAL_AUTHORITY_ASSET_SPEC,
    GCSUKGeographyAssetStrategy,
    LocalUKGeographyAssetStrategy,
    UKGeographyAssetPaths,
    UKGeographyAssetSpec,
    UKGeographyAssetStrategy,
    default_uk_geography_asset_strategies,
    resolve_uk_geography_asset_paths,
)
from policyengine.outputs.uk_geography_disclosure import (
    UKGeographyDisclosure,
    compute_uk_geography_disclosure,
)

__all__ = [
    "Output",
    "OutputCollection",
    "Aggregate",
    "AggregateType",
    "ChangeAggregate",
    "ChangeAggregateType",
    "CliffImpact",
    "CliffImpactInSimulation",
    "calculate_cliff_impact",
    "configure_cliff_impact_variables",
    "DecileImpact",
    "calculate_decile_impacts",
    "ProgramStatistics",
    "build_program_statistics",
    "validate_program_statistics_config",
    "IntraDecileImpact",
    "compute_intra_decile_impacts",
    "HoursResponse",
    "LaborSupplyResponse",
    "calculate_labor_supply_response",
    "configure_labor_supply_response_variables",
    "labor_supply_response_is_active",
    "Poverty",
    "UKPovertyType",
    "USPovertyType",
    "UK_POVERTY_VARIABLES",
    "US_POVERTY_VARIABLES",
    "calculate_uk_poverty_rates",
    "calculate_us_poverty_rates",
    "calculate_uk_poverty_by_age",
    "calculate_us_poverty_by_age",
    "calculate_uk_poverty_by_gender",
    "calculate_us_poverty_by_gender",
    "calculate_us_poverty_by_race",
    "AGE_GROUPS",
    "GENDER_GROUPS",
    "RACE_GROUPS",
    "Inequality",
    "USInequalityPreset",
    "UK_INEQUALITY_INCOME_VARIABLE",
    "US_INEQUALITY_INCOME_VARIABLE",
    "calculate_uk_inequality",
    "calculate_us_inequality",
    "CongressionalDistrictImpact",
    "compute_us_congressional_district_impacts",
    "ConstituencyImpact",
    "compute_uk_constituency_impacts",
    "LocalAuthorityImpact",
    "compute_uk_local_authority_impacts",
    "UKGeographyDisclosure",
    "compute_uk_geography_disclosure",
    "CONSTITUENCY_ASSET_SPEC",
    "LOCAL_AUTHORITY_ASSET_SPEC",
    "GCSUKGeographyAssetStrategy",
    "LocalUKGeographyAssetStrategy",
    "UKGeographyAssetPaths",
    "UKGeographyAssetSpec",
    "UKGeographyAssetStrategy",
    "default_uk_geography_asset_strategies",
    "resolve_uk_geography_asset_paths",
]
