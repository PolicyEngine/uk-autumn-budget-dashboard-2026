import copy
import hashlib
import json
import logging
from datetime import datetime
from typing import Any, Optional, Union
from uuid import uuid4

from pydantic import BaseModel, Field, model_validator

from .cache import LRUCache
from .dataset import Dataset
from .dynamic import Dynamic
from .policy import Policy
from .scoping_strategy import ScopingStrategy
from .spm import SPMProvenance, SPMSelection
from .tax_benefit_model_version import StaleOutputError, TaxBenefitModelVersion

logger = logging.getLogger(__name__)

_cache: LRUCache["Simulation"] = LRUCache(max_size=100)


class Simulation(BaseModel):
    """Population microsimulation over a certified dataset.

    Canonical call shape:

    .. code-block:: python

        import policyengine as pe
        from policyengine.core import Simulation

        datasets = pe.us.ensure_datasets(years=[2026], data_folder="./data")
        dataset = next(iter(datasets.values()))

        # Baseline
        baseline = Simulation(dataset=dataset, tax_benefit_model_version=pe.us.model)

        # Reform — same flat dict shape as pe.us.calculate_household(reform=...).
        # Parameter path indexing uses "[0].amount" for scale/breakdown entries.
        reform = Simulation(
            dataset=dataset,
            tax_benefit_model_version=pe.us.model,
            policy={"gov.irs.credits.ctc.amount.base[0].amount": 3_000},
        )

        baseline.ensure()
        reform.ensure()

    The ``policy`` / ``dynamic`` kwargs accept either a ``Policy`` /
    ``Dynamic`` object or a flat ``{"param.path": value}`` /
    ``{"param.path": {date: value}}`` dict that is compiled against
    ``tax_benefit_model_version`` at construction time (unknown paths
    raise with close-match suggestions). Scalar values default to
    ``{dataset.year}-01-01`` as their effective date.

    See ``policyengine.core.scoping_strategy`` for sub-national scoping.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)

    policy: Optional[Union[Policy, dict[str, Any]]] = Field(
        default=None,
        description=(
            "Reform policy. Pass a ``Policy`` directly, or a flat "
            "``{'param.path': value}`` / ``{'param.path': {date: value}}`` "
            "dict and it will be compiled against "
            "``tax_benefit_model_version`` at run time."
        ),
    )
    dynamic: Optional[Union[Dynamic, dict[str, Any]]] = Field(
        default=None,
        description=(
            "Behavioural-response overlay. Same dict shape as ``policy``. "
            "``None`` keeps the country model's defaults, which need not be "
            "static: policyengine-uk realises capital gains at a "
            "retention-rate elasticity of 1 by default."
        ),
    )
    dataset: Dataset = None

    scoping_strategy: Optional[ScopingStrategy] = Field(
        default=None,
        description="Strategy for scoping dataset to a sub-national region",
    )

    extra_variables: dict[str, list[str]] = Field(
        default_factory=dict,
        description=(
            "Additional variables to calculate beyond the model version's "
            "default entity_variables, keyed by entity name. Use when a "
            "caller needs variables that are not in the bundled default set."
        ),
    )

    tax_benefit_model_version: TaxBenefitModelVersion = None

    output_dataset: Optional[Dataset] = None

    spm: Optional[SPMSelection] = Field(
        default=None,
        description="US SPM forecast and geography selection within the release bundle.",
    )
    spm_receipt: Optional[SPMProvenance] = Field(
        default=None,
        description="Detached SPM calculation receipt, populated by a US run or load.",
    )

    @property
    def spm_config(self) -> Optional[dict[str, Any]]:
        """Resolve the US measurement selection without retaining a country object."""
        if getattr(self.tax_benefit_model_version, "country_code", None) != "us":
            if self.spm is not None:
                raise ValueError("SPM selection is only supported by the US model")
            return None
        from policyengine.tax_benefit_models.us.spm import resolve_spm_selection

        return resolve_spm_selection(self.spm)

    def spm_provenance(self) -> Optional[dict[str, Any]]:
        """Return a detached JSON receipt, or None before a US calculation."""
        return (
            self.spm_receipt.model_dump(mode="json")
            if self.spm_receipt is not None
            else None
        )

    @property
    def storage_id(self) -> str:
        """Include resolved SPM settings, and a UK run's explicit capital
        gains response settings, in cache and saved-result identity."""
        storage_id = self.id
        config = self.spm_config
        if config is not None:
            encoded = json.dumps(config, sort_keys=True, separators=(",", ":"))
            storage_id += f"-spm-{hashlib.sha256(encoded.encode()).hexdigest()}"
        if getattr(self.tax_benefit_model_version, "country_code", None) == "uk":
            from policyengine.tax_benefit_models.uk.capital_gains_responses import (
                simulation_request,
            )

            digest = simulation_request(self)["digest"]
            if digest is not None:
                storage_id += f"-cgr-{digest}"
        return storage_id

    @model_validator(mode="after")
    def _compile_dict_reforms(self) -> "Simulation":
        """Coerce dict ``policy`` / ``dynamic`` inputs into proper objects.

        Runs at ``mode="after"`` because compiling needs both
        ``tax_benefit_model_version`` (for path validation) and
        ``dataset.year`` (for effective-date defaulting) — both on ``self``.
        """
        from policyengine.tax_benefit_models.common.reform import (
            compile_reform_to_dynamic,
            compile_reform_to_policy,
        )

        year = getattr(self.dataset, "year", None)
        for field, compiler in (
            ("policy", compile_reform_to_policy),
            ("dynamic", compile_reform_to_dynamic),
        ):
            value = getattr(self, field)
            if not isinstance(value, dict):
                continue
            if self.tax_benefit_model_version is None:
                raise ValueError(
                    f"Cannot compile a dict {field} without "
                    "tax_benefit_model_version; pass model_version or a "
                    f"{field.capitalize()}."
                )
            setattr(
                self,
                field,
                compiler(
                    value, year=year, model_version=self.tax_benefit_model_version
                ),
            )
        return self

    def run(self):
        # Reject unsupported country settings even on model paths that do not
        # use US measurement. Results from an earlier run are no longer valid.
        if self.spm_config is not None:
            self.spm_receipt = None
            self.output_dataset = None
        self.tax_benefit_model_version.run(self)

    def ensure(self):
        cache_key = self.storage_id
        cached_result = _cache.get(cache_key)
        if cached_result:
            self.output_dataset = cached_result.output_dataset
            self.spm = cached_result.spm
            self.spm_receipt = (
                cached_result.spm_receipt.model_copy(deep=True)
                if cached_result.spm_receipt is not None
                else None
            )
            return
        try:
            self.tax_benefit_model_version.load(self)
        except FileNotFoundError:
            self.run()
            self.save()
        except StaleOutputError as error:
            # An expected rerun, such as the first after an upgrade that
            # changes what saved outputs record.
            logger.info("Running simulation %s again: %s", self.id, error)
            self.run()
            self.save()
        except Exception:
            logger.warning(
                "Unexpected error loading simulation %s; falling back to run()",
                self.id,
                exc_info=True,
            )
            self.run()
            self.save()

        # Cache a snapshot: changing this Simulation's selection then running
        # it again must not overwrite the receipt for an earlier cache key.
        _cache.add(
            cache_key,
            self.model_copy(
                update={
                    "spm_receipt": self.spm_receipt.model_copy(deep=True)
                    if self.spm_receipt is not None
                    else None
                }
            ),
        )

    def save(self):
        """Save the simulation's output dataset."""
        self.tax_benefit_model_version.save(self)

    def load(self):
        """Load the simulation's output dataset."""
        self.tax_benefit_model_version.load(self)

    def write_run_record(self, directory, **kwargs):
        """Write a citable, offline-verifiable run record directory.

        See :func:`policyengine.core.run_record.write_simulation_run_record`
        for the file layout and options. The returned record's
        ``composition_fingerprint`` is the citable identifier for this run.
        """
        from .run_record import write_simulation_run_record

        return write_simulation_run_record(self, directory, **kwargs)

    @property
    def release_bundle(self) -> dict[str, Any]:
        bundle = (
            self.tax_benefit_model_version.release_bundle
            if self.tax_benefit_model_version is not None
            else {}
        )
        result: dict[str, Any] = {
            **bundle,
            "dataset_filepath": self.dataset.filepath
            if self.dataset is not None
            else None,
        }
        if self.spm_config is not None:
            recorded = getattr(self.output_dataset, "metadata", {}).get("spm_config")
            result["spm_config"] = dict(recorded or self.spm_config)
            result["spm"] = self.spm_provenance()
        # Stored inputs the country loader mapped onto renamed live inputs
        # (for example the US WIC take-up draw), as the run recorded them.
        # See ``policyengine.tax_benefit_models.us.legacy_inputs``.
        renames = (getattr(self.output_dataset, "metadata", None) or {}).get(
            "legacy_input_renames"
        )
        if renames is not None:
            result["legacy_input_renames"] = dict(renames)
        # BACKWARD COMPATIBILITY (#597, #598): the legacy SPM declarations a
        # US run applied, which change its SPM results. See
        # ``policyengine.tax_benefit_models.us.legacy_spm``.
        legacy_spm_declarations = (
            getattr(self.output_dataset, "metadata", None) or {}
        ).get("legacy_spm_declarations")
        if legacy_spm_declarations is not None:
            result["legacy_spm_declarations"] = dict(legacy_spm_declarations)
        # The capital gains realisation response a UK run applied. See
        # ``policyengine.tax_benefit_models.uk.capital_gains_responses``.
        capital_gains_responses = (
            getattr(self.output_dataset, "metadata", None) or {}
        ).get("capital_gains_responses")
        if capital_gains_responses is not None:
            result["capital_gains_responses"] = copy.deepcopy(capital_gains_responses)
        return result
