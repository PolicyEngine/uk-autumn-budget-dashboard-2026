import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import pandas as pd
from microdf import MicroDataFrame

from policyengine.core import TaxBenefitModel
from policyengine.provenance.dataset_materialization import (
    materialize_dataset,
)
from policyengine.tax_benefit_models.common import MicrosimulationModelVersion
from policyengine.tax_benefit_models.common.model_version import (
    build_runtime_dataset_provenance,
)
from policyengine.tax_benefit_models.common.model_version import (
    output_dataset_filepath as _output_dataset_filepath,
)

from .datasets import PolicyEngineUSDataset, USYearData, _validate_entity_ids
from .legacy_inputs import (
    RENAMES_RECORD_KEY,
    apply_legacy_input_renames,
    apply_legacy_input_renames_to_microsimulation,
)
from .legacy_spm import (
    RECORD_KEY as LEGACY_SPM_RECORD_KEY,
)
from .legacy_spm import (
    derive_from_stored_tables,
    legacy_spm_for_run,
    legacy_spm_source,
    prepare_microsimulation,
    set_declarations,
)
from .spm import (
    SPMProvenance,
    SPMSelection,
    calculation_provenance,
    resolve_spm_selection,
)

if TYPE_CHECKING:
    from policyengine.core.simulation import Simulation

US_GROUP_ENTITIES = [
    "household",
    "tax_unit",
    "spm_unit",
    "family",
    "marital_unit",
]


class PolicyEngineUS(TaxBenefitModel):
    id: str = "policyengine-us"
    description: str = "The US's open-source dynamic tax and benefit microsimulation model maintained by PolicyEngine."


us_model = PolicyEngineUS()


class PolicyEngineUSLatest(MicrosimulationModelVersion):
    country_code = "us"
    package_name = "policyengine-us"
    group_entities = US_GROUP_ENTITIES

    model: TaxBenefitModel = us_model
    version: str = None
    created_at: datetime.datetime = None

    entity_variables: dict[str, list[str]] = {
        "person": [
            # IDs and weights
            "person_id",
            "marital_unit_id",
            "family_id",
            "spm_unit_id",
            "tax_unit_id",
            "household_id",
            "person_weight",
            # Demographics
            "age",
            "is_male",
            "race",
            "is_child",
            "is_adult",
            # Income
            "employment_income",
            # Benefits
            "ssi",
            "social_security",
            "medicare_cost",
            "medicaid",
            "unemployment_compensation",
        ],
        "marital_unit": [
            "marital_unit_id",
            "marital_unit_weight",
        ],
        "family": [
            "family_id",
            "family_weight",
        ],
        "spm_unit": [
            "spm_unit_id",
            "spm_unit_weight",
            "snap",
            "tanf",
            "spm_unit_net_income",
            # Poverty measures
            "spm_unit_is_in_spm_poverty",
            "spm_unit_is_in_deep_spm_poverty",
        ],
        "tax_unit": [
            "tax_unit_id",
            "tax_unit_weight",
            "income_tax",
            "employee_payroll_tax",
            "state_income_tax",
            "household_state_income_tax",
            "eitc",
            "ctc",
        ],
        "household": [
            "household_id",
            "household_weight",
            "household_count_people",
            "household_net_income",
            "household_income_decile",
            "household_benefits",
            "household_tax",
            "household_market_income",
            "congressional_district_geoid",
        ],
    }

    # --- Hooks -----------------------------------------------------------
    @classmethod
    def _get_runtime_data_build_metadata(cls) -> dict[str, Optional[str]]:
        try:
            from policyengine_us.build_metadata import get_data_build_metadata
        except ModuleNotFoundError as exc:
            if exc.name != "policyengine_us.build_metadata":
                raise
            return {}
        return get_data_build_metadata() or {}

    def _load_system(self):
        from policyengine_us.system import system

        return system

    def _load_region_registry(self):
        from policyengine.countries.us.regions import us_region_registry

        return us_region_registry

    @property
    def _dataset_class(self):
        return PolicyEngineUSDataset

    # --- run -------------------------------------------------------------
    def run(self, simulation: "Simulation") -> "Simulation":
        from policyengine_us import Microsimulation

        from policyengine.utils.parametric_reforms import (
            build_reform_dict,
            merge_reform_dicts,
        )

        assert isinstance(simulation.dataset, PolicyEngineUSDataset)

        dataset = simulation.dataset
        # Load from disk only when the caller did not already supply data.
        # An unconditional reload discards caller-provided in-memory data
        # and forced construction to persist datasets to disk (see the
        # autosave removal in datasets.py).
        if dataset.data is None:
            dataset.load()

        # Validate every entity before constructing either the reform or its
        # baseline, so no set_input can suppress a canonical SPM formula.
        from spm_calculator.policyengine_adapter import validate_policyengine_inputs

        validate_policyengine_inputs(dataset.data.entity_data)

        # BACKWARD COMPATIBILITY (#597, #598): a legacy certified source
        # carries no SPM declarations. A year file cut from one stores them;
        # a run straight over one derives them now (see ``legacy_spm``).
        legacy_spm = legacy_spm_for_run(dataset)

        # Apply regional scoping if specified
        if simulation.scoping_strategy:
            scoped_data = simulation.scoping_strategy.apply(
                entity_data=dataset.data.entity_data,
                group_entities=US_GROUP_ENTITIES,
                year=dataset.year,
            )
            dataset = PolicyEngineUSDataset(
                id=dataset.id + "_scoped",
                name=dataset.name,
                description=dataset.description,
                # Derived in-memory copy: no filepath, so it can never be
                # persisted back over the shared source file it was filtered
                # from.
                filepath=None,
                year=dataset.year,
                is_output_dataset=dataset.is_output_dataset,
                data=USYearData(
                    person=scoped_data["person"],
                    marital_unit=scoped_data["marital_unit"],
                    family=scoped_data["family"],
                    spm_unit=scoped_data["spm_unit"],
                    tax_unit=scoped_data["tax_unit"],
                    household=scoped_data["household"],
                ),
            )

        # US requires reforms at Microsimulation construction time
        # (unlike UK which supports p.update() after construction).
        policy_reform = build_reform_dict(simulation.policy)
        dynamic_reform = build_reform_dict(simulation.dynamic)
        reform_dict = merge_reform_dicts(policy_reform, dynamic_reform)

        class InputMicrosimulation(Microsimulation):
            # The caller already supplied the entire dataset. The country
            # default would load another population before we build this one.
            default_dataset = None

        microsim = InputMicrosimulation(
            situation={},
            reform=reform_dict,
            spm=simulation.spm_config,
            default_input_period=dataset.year,
        )
        legacy_spm_mode = None
        if legacy_spm is not None:
            # BACKWARD COMPATIBILITY (#597, #598): after construction, so every
            # policy and structural reform is in place, and before populations
            # are built, so stored declarations load as inputs in the reform
            # and its baseline.
            legacy_spm_mode = prepare_microsimulation(microsim)
        # Use ``microsim.tax_benefit_system``, not the module-level
        # ``system``: ``Microsimulation.__init__`` applies structural
        # reforms (e.g. ``gov.contrib.ctc.*``) to its per-sim system but
        # leaves the module-level one untouched. Building populations
        # against the module-level system would hide reform-registered
        # variables like ``ctc_minimum_refundable_amount`` at calc time.
        # Renames already applied when the input data was cut (a
        # ``create_datasets`` year file stores the mapped input under its
        # live name) count as applied to this run's inputs too, so the
        # output's record keeps the whole chain.
        legacy_input_renames: dict[str, str] = dict(
            simulation.dataset.metadata.get(RENAMES_RECORD_KEY) or {}
        )
        if microsim.baseline is not None:
            legacy_input_renames.update(
                self._build_simulation_from_dataset(
                    microsim.baseline,
                    dataset,
                    microsim.baseline.tax_benefit_system,
                )
            )
        legacy_input_renames.update(
            self._build_simulation_from_dataset(
                microsim, dataset, microsim.tax_benefit_system
            )
        )
        if legacy_spm is not None and legacy_spm.in_memory is not None:
            # BACKWARD COMPATIBILITY (#597, #598): declarations derived from a
            # raw legacy source are set on the simulation and its baseline.
            set_declarations(microsim, legacy_spm.in_memory, [dataset.year])

        data = {
            "person": pd.DataFrame(),
            "marital_unit": pd.DataFrame(),
            "family": pd.DataFrame(),
            "spm_unit": pd.DataFrame(),
            "tax_unit": pd.DataFrame(),
            "household": pd.DataFrame(),
        }

        # ID columns should be preserved from input dataset, not calculated
        id_columns = {
            "person_id",
            "household_id",
            "marital_unit_id",
            "family_id",
            "spm_unit_id",
            "tax_unit_id",
        }
        weight_columns = {
            "person_weight",
            "household_weight",
            "marital_unit_weight",
            "family_weight",
            "spm_unit_weight",
            "tax_unit_weight",
        }

        # Copy ID and weight columns from input dataset.
        for entity in data.keys():
            input_df = pd.DataFrame(getattr(dataset.data, entity))
            entity_id_col = f"{entity}_id"
            entity_weight_col = f"{entity}_weight"

            if entity_id_col in input_df.columns:
                data[entity][entity_id_col] = input_df[entity_id_col].values
            if entity_weight_col in input_df.columns:
                data[entity][entity_weight_col] = input_df[entity_weight_col].values

        # Person entity also needs person-level group ID columns so that
        # downstream joins (e.g. person->tax_unit) work.
        person_input_df = pd.DataFrame(dataset.data.person)
        for entity in US_GROUP_ENTITIES:
            target_col = f"{entity}_id"
            native_col = f"person_{target_col}"
            source_col = (
                native_col if native_col in person_input_df.columns else target_col
            )
            if source_col in person_input_df.columns:
                data["person"][target_col] = person_input_df[source_col].values

        # Calculate non-ID, non-weight variables from simulation.
        # ``resolve_entity_variables`` merges bundled defaults with
        # caller-supplied ``simulation.extra_variables``; unknown
        # entity keys or variable names raise with close-match hints.
        for entity, variables in self.resolve_entity_variables(simulation).items():
            # Country populations use their own ID order. Restore each native
            # table's order before attaching values to its IDs and weights.
            input_ids = pd.DataFrame(getattr(dataset.data, entity))[f"{entity}_id"]
            output_order = pd.Index(microsim.populations[entity].ids).get_indexer(
                input_ids
            )
            if (output_order < 0).any():
                raise ValueError(f"Missing {entity}_id in simulation output")
            for var in variables:
                if var not in id_columns and var not in weight_columns:
                    data[entity][var] = microsim.calculate(
                        var, period=simulation.dataset.year, map_to=entity
                    ).values[output_order]

        data["person"] = MicroDataFrame(data["person"], weights="person_weight")
        data["marital_unit"] = MicroDataFrame(
            data["marital_unit"], weights="marital_unit_weight"
        )
        data["family"] = MicroDataFrame(data["family"], weights="family_weight")
        data["spm_unit"] = MicroDataFrame(data["spm_unit"], weights="spm_unit_weight")
        data["tax_unit"] = MicroDataFrame(data["tax_unit"], weights="tax_unit_weight")
        data["household"] = MicroDataFrame(
            data["household"], weights="household_weight"
        )

        output_metadata = {
            "spm_config": dict(microsim.spm_config),
            RENAMES_RECORD_KEY: dict(sorted(legacy_input_renames.items())),
        }
        if legacy_spm is not None:
            output_metadata[LEGACY_SPM_RECORD_KEY] = legacy_spm.record.model_copy(
                update={"model_mode": legacy_spm_mode}
            ).model_dump(mode="json")
        simulation.output_dataset = PolicyEngineUSDataset(
            id=simulation.id,
            name=dataset.name,
            description=dataset.description,
            filepath=str(_output_dataset_filepath(simulation)),
            year=simulation.dataset.year,
            is_output_dataset=True,
            metadata=output_metadata,
            data=USYearData(
                person=data["person"],
                marital_unit=data["marital_unit"],
                family=data["family"],
                spm_unit=data["spm_unit"],
                tax_unit=data["tax_unit"],
                household=data["household"],
            ),
        )
        simulation.spm_receipt = SPMProvenance.model_validate(
            calculation_provenance(microsim)
        )
        simulation.spm = SPMSelection.model_validate(microsim.spm_config)

    def _build_simulation_from_dataset(self, microsim, dataset, system):
        """Build a PolicyEngine Core simulation from dataset entity IDs.

        Mirrors the policyengine-uk pattern of instantiating entities from
        IDs first and then setting variable inputs. Handles both the legacy
        ``person_X_id`` and the ``X_id`` column-naming conventions.

        Stored columns the engine has since renamed are mapped onto their
        live inputs (see ``legacy_inputs.LEGACY_INPUT_RENAMES``).

        Returns:
            The legacy input renames applied, ``{legacy: live}``.
        """
        import numpy as np
        from policyengine_core.simulations.simulation_builder import (
            SimulationBuilder,
        )
        from spm_calculator.policyengine_adapter import validate_policyengine_inputs

        validate_policyengine_inputs(dataset.data.entity_data)
        _validate_entity_ids(dataset.data.entity_data)

        builder = SimulationBuilder()
        builder.populations = system.instantiate_entities()

        person_data = pd.DataFrame(dataset.data.person)

        household_id_col = (
            "person_household_id"
            if "person_household_id" in person_data.columns
            else "household_id"
        )
        marital_unit_id_col = (
            "person_marital_unit_id"
            if "person_marital_unit_id" in person_data.columns
            else "marital_unit_id"
        )
        family_id_col = (
            "person_family_id"
            if "person_family_id" in person_data.columns
            else "family_id"
        )
        spm_unit_id_col = (
            "person_spm_unit_id"
            if "person_spm_unit_id" in person_data.columns
            else "spm_unit_id"
        )
        tax_unit_id_col = (
            "person_tax_unit_id"
            if "person_tax_unit_id" in person_data.columns
            else "tax_unit_id"
        )

        # The builder requires membership IDs and declared population IDs to
        # describe the same groups. Check explicitly before its positional
        # membership mapping can silently attach a person to a different group.
        for entity, link in {
            "household": household_id_col,
            "marital_unit": marital_unit_id_col,
            "family": family_id_col,
            "spm_unit": spm_unit_id_col,
            "tax_unit": tax_unit_id_col,
        }.items():
            if link not in person_data or person_data[link].isna().any():
                raise ValueError(f"Missing nonnull person {link} membership")
            entity_ids = pd.DataFrame(getattr(dataset.data, entity))[f"{entity}_id"]
            if set(entity_ids) != set(person_data[link]):
                raise ValueError(
                    f"Native {entity}_id values must match person {link} memberships"
                )

        builder.declare_person_entity("person", person_data["person_id"].values)
        builder.declare_entity(
            "household", np.unique(person_data[household_id_col].values)
        )
        builder.declare_entity(
            "spm_unit", np.unique(person_data[spm_unit_id_col].values)
        )
        builder.declare_entity("family", np.unique(person_data[family_id_col].values))
        builder.declare_entity(
            "tax_unit", np.unique(person_data[tax_unit_id_col].values)
        )
        builder.declare_entity(
            "marital_unit", np.unique(person_data[marital_unit_id_col].values)
        )

        builder.join_with_persons(
            builder.populations["household"],
            person_data[household_id_col].values,
            np.array(["member"] * len(person_data)),
        )
        builder.join_with_persons(
            builder.populations["spm_unit"],
            person_data[spm_unit_id_col].values,
            np.array(["member"] * len(person_data)),
        )
        builder.join_with_persons(
            builder.populations["family"],
            person_data[family_id_col].values,
            np.array(["member"] * len(person_data)),
        )
        builder.join_with_persons(
            builder.populations["tax_unit"],
            person_data[tax_unit_id_col].values,
            np.array(["member"] * len(person_data)),
        )
        builder.join_with_persons(
            builder.populations["marital_unit"],
            person_data[marital_unit_id_col].values,
            np.array(["member"] * len(person_data)),
        )

        microsim.build_from_populations(builder.populations)

        id_columns = {
            "person_id",
            "household_id",
            "person_household_id",
            "spm_unit_id",
            "person_spm_unit_id",
            "family_id",
            "person_family_id",
            "tax_unit_id",
            "person_tax_unit_id",
            "marital_unit_id",
            "person_marital_unit_id",
        }

        stored_tables = {}
        for entity_name, entity_df in [
            ("person", dataset.data.person),
            ("household", dataset.data.household),
            ("spm_unit", dataset.data.spm_unit),
            ("family", dataset.data.family),
            ("tax_unit", dataset.data.tax_unit),
            ("marital_unit", dataset.data.marital_unit),
        ]:
            df = pd.DataFrame(entity_df).set_index(f"{entity_name}_id", drop=False)
            df = df.loc[microsim.populations[entity_name].ids]
            stored_tables[entity_name] = df
            for column in df.columns:
                if column not in id_columns and column in system.variables:
                    microsim.set_input(column, dataset.year, df[column].values)

        # The loop above skips columns the engine does not define, including
        # stored inputs it has since renamed. The tables are already in the
        # simulation's entity order.
        return apply_legacy_input_renames(microsim, {dataset.year: stored_tables})


def managed_microsimulation(
    *,
    dataset: Optional[str] = None,
    allow_unmanaged: bool = False,
    spm: Optional[SPMSelection] = None,
    **kwargs,
):
    """Construct a country-package Microsimulation pinned to this bundle.

    By default this enforces the dataset selection from the bundled
    ``policyengine.py`` release manifest. Arbitrary dataset URIs require
    ``allow_unmanaged=True``.

    Stored inputs the engine has since renamed are mapped onto their live
    inputs (see ``legacy_inputs.LEGACY_INPUT_RENAMES``), and the renames
    applied are recorded as ``policyengine_bundle["legacy_input_renames"]``.
    """

    from policyengine_us import Microsimulation

    if "dataset" in kwargs:
        raise ValueError(
            "Pass `dataset=` directly to managed_microsimulation, not through "
            "**kwargs, so policyengine.py can enforce the release bundle."
        )

    selection = resolve_spm_selection(spm)
    source = materialize_dataset(
        "us",
        dataset,
        allow_unmanaged=allow_unmanaged,
    )
    microsim = Microsimulation(dataset=source.path, spm=selection, **kwargs)
    legacy_input_renames = apply_legacy_input_renames_to_microsimulation(microsim)
    # BACKWARD COMPATIBILITY (#597, #598): a legacy certified source carries
    # no SPM declarations, so derive them from its stored evidence and set
    # them on the simulation and its branches (see ``legacy_spm``).
    legacy_spm_record = None
    legacy_source = legacy_spm_source(
        source.bundle_dataset.sha256 if source.bundle_dataset else None
    )
    if legacy_source is not None:
        declarations, years = derive_from_stored_tables(
            legacy_source, microsim.dataset, data_dir=Path(source.path).parent
        )
        mode = prepare_microsimulation(microsim)
        set_declarations(microsim, declarations, years)
        legacy_spm_record = declarations.record.model_copy(
            update={"model_mode": mode}
        ).model_dump(mode="json")
    microsim.policyengine_bundle = dict(us_latest.release_bundle)
    microsim.policyengine_bundle.update(
        build_runtime_dataset_provenance(
            source.source_uri,
            source.path,
            source.bundle_dataset,
        )
    )
    microsim.policyengine_bundle["spm"] = dict(microsim.spm_config)
    microsim.policyengine_bundle[RENAMES_RECORD_KEY] = dict(
        sorted(legacy_input_renames.items())
    )
    if legacy_spm_record is not None:
        microsim.policyengine_bundle[LEGACY_SPM_RECORD_KEY] = legacy_spm_record
    return microsim


us_latest = PolicyEngineUSLatest()
