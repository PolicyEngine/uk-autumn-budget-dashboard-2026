"""US congressional district definitions.

Based on 2020 Census apportionment.
Total: 435 voting representatives + 1 DC non-voting delegate = 436
"""

# Congressional district counts by state (2020 Census apportionment)
# States with 1 district are "at-large"
DISTRICT_COUNTS: dict[str, int] = {
    "AL": 7,
    "AK": 1,
    "AZ": 9,
    "AR": 4,
    "CA": 52,
    "CO": 8,
    "CT": 5,
    "DE": 1,
    "DC": 1,  # Non-voting delegate
    "FL": 28,
    "GA": 14,
    "HI": 2,
    "ID": 2,
    "IL": 17,
    "IN": 9,
    "IA": 4,
    "KS": 4,
    "KY": 6,
    "LA": 6,
    "ME": 2,
    "MD": 8,
    "MA": 9,
    "MI": 13,
    "MN": 8,
    "MS": 4,
    "MO": 8,
    "MT": 2,
    "NE": 3,
    "NV": 4,
    "NH": 2,
    "NJ": 12,
    "NM": 3,
    "NY": 26,
    "NC": 14,
    "ND": 1,
    "OH": 15,
    "OK": 5,
    "OR": 6,
    "PA": 17,
    "RI": 2,
    "SC": 7,
    "SD": 1,
    "TN": 9,
    "TX": 38,
    "UT": 4,
    "VT": 1,
    "VA": 11,
    "WA": 10,
    "WV": 2,
    "WI": 8,
    "WY": 1,
}

# States with at-large congressional districts (single representative)
AT_LARGE_STATES: set[str] = {"AK", "DE", "DC", "ND", "SD", "VT", "WY"}
